import cv2

im = cv2.imread("TokenThresh.png")
cv2.imshow("asjdkfd", im)
cv2.waitKey(0)